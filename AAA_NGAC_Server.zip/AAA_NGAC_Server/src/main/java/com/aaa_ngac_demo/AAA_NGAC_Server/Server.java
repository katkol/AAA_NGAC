package com.aaa_ngac_demo.AAA_NGAC_Server;

import java.util.logging.ConsoleHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.eclipse.californium.core.CoapServer;
import org.eclipse.californium.core.network.CoapEndpoint;
import org.eclipse.californium.core.network.EndpointManager;
import org.eclipse.californium.core.network.config.NetworkConfig;

import com.aaa_ngac_demo.AAA_NGAC_Server.ngac_database.*;
import com.aaa_ngac_demo.AAA_NGAC_Server.AAACoapServer.*;
import com.aaa_ngac_demo.AAA_NGAC_Server.arrowhead_models.*;
import org.hibernate.*;


/**
 * Hello world!
 *
 */
public class Server 
{
    private static final Logger LOG = Logger.getLogger(Server.class.getName());
    public static void main( String[] args )
    {
    	LOG.info("Inside log Server started");

    	createNodes();
        
        CoapServ server = new CoapServ();
      //  server.addEndpoints();
        server.start();

    }
    
    public static void createNodes()
    {
        Declarations d = new Declarations();
        Procedures pr= new Procedures();
        d.add_nodeTypes();
        d.add_OperationTypes();
        node node1= new node(d.User,"Node1", "User: Blinder sys");
        node node2= new node(d.User,"Node2", "User: Heating sys");
        node node3= new node(d.User,"Node3", "User: owner user");
        node node4 = new node(d.U_attr,"Node4", "Attribute: House sys"); 
        node node5  = new node(d.U_attr,"Node5", "Attribute:Administrator"); 
        node node6 = new node(d.Obj,"Node6", "Object: Temperature sensor 1");
        node node7 = new node(d.Obj,"Node7", "Object: Temperature sensor 2");
        node node8 = new node(d.Obj,"Node8", "Object:Central sys"); 
        node node9 = new node(d.O_attr,"Node9", "Attribute: Outside"); 
        node node10 = new node(d.O_attr,"Node10", "Attribute:Inside");
        node node11= new node(d.O_attr,"Node11", "Attribute: Status"); 
        node node12 = new node(d.O_attr,"Node12", "Attribute: Temperatures"); 
        node node13 = new node(d.Oper,"get_temp", "Operation:Read the temperature");
        node node14= new node(d.Oper,"get_status", "Operation:Read the status ");
        
        operation op1 = new operation(d.resource,"get_temp","Read the temperature of a sensor and the time that it is taken");
        operation op2 = new operation(d.resource,"get_status","Read the status");
        operation_set set1 = new operation_set(op1,node13);
        operation_set set2 = new operation_set(op2,node14);
        
        arrowheadsystem sys1= new arrowheadsystem("105.105.10.987","Feb2","8000","Blinder_sys",node1);
        arrowheadsystem sys2= new arrowheadsystem("105.105.10.987","Feb2","8000","Heating_sys",node2);
        arrowheadsystem sys3= new arrowheadsystem("105.105.10.987","Feb2","8000","Owner_user",node3);
        arrowheadsystem sys4= new arrowheadsystem("105.105.10.987","Feb2","8000","Temperature_sensor1",node6);
        arrowheadsystem sys5= new arrowheadsystem("105.105.10.987","Feb2","8000","Temperature_sensor2",node7);
        arrowheadsystem sys6= new arrowheadsystem("105.105.10.987","Feb2","8000","Central_sys",node8);
        
        
        arrowheadservice ser1 = new arrowheadservice("metadata","get_temp",set1);
        arrowheadservice ser2 = new arrowheadservice("metadata","get_status",set2);
        
        arrowheadcloud cloud= new arrowheadcloud("A","Cloud1","Operator A"); 
        
        DatabaseManager databaseManager=new DatabaseManager();
        Session session=databaseManager.getSessionFactory().openSession();
        session.beginTransaction();  
 
        session.save(node1);        
        session.save(node2);
        session.save(node3);
        session.save(node4);
        session.save(node5);
        session.save(node6);
        session.save(node7);
        session.save(node8);
        session.save(node9);
        session.save(node10);
        session.save(node11);
        session.save(node12);
        session.save(node13);
        session.save(node14);
        
        session.save(op1);
        session.save(set1);
        session.save(op2);
        session.save(set2);
        
        session.save(sys1);
        session.save(sys2);
        session.save(sys3);
        session.save(sys4);
        session.save(sys5);
        session.save(sys6);
        
       
        session.save(ser1);
        session.save(ser2);
        
        session.save(cloud);
        
        session.getTransaction().commit();
        session.close();
        
        pr.createAssignment(node1,node4);
        pr.createAssignment(node2,node4);
        pr.createAssignment(node3,node5);
        pr.createAssignment(node6,node9);
        pr.createAssignment(node9,node12);
        pr.createAssignment(node7,node10);
        pr.createAssignment(node10,node12);
        pr.createAssignment(node8,node11);
        
        pr.createAssociation(node4, node12,"get_temp", op1);
        pr.createAssociation(node5, node11,"get_status", op2);
    }
}
