package com.aaa_ngac_demo.AAA_NGAC_Server.exceptions;

public class DataNotFoundException extends RuntimeException{
	
	
	private static final long serialVersionUID = -1622261264080480479L;

	public DataNotFoundException(String message) {
		super(message);
	}
}
