package com.aaa_ngac_demo.AAA_NGAC_Consumer;

import java.io.ByteArrayInputStream;
import java.util.concurrent.TimeUnit;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.StringWriter;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.URISyntaxException;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.Certificate;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.logging.Logger;
import java.util.logging.Level;
import java.util.logging.LogManager;

import org.eclipse.californium.core.CoapClient;
import org.eclipse.californium.core.CoapResponse;
import org.eclipse.californium.core.network.CoapEndpoint;
import org.eclipse.californium.core.network.EndpointManager;
import org.eclipse.californium.core.network.config.NetworkConfig;
import org.eclipse.californium.scandium.DTLSConnector;
import org.eclipse.californium.scandium.config.DtlsConnectorConfig;
import org.eclipse.californium.scandium.dtls.DTLSSession;
import org.eclipse.californium.scandium.dtls.cipher.CipherSuite;

import org.jose4j.jwt.consumer.JwtConsumer;
import org.jose4j.jwa.AlgorithmConstraints;
import org.jose4j.jwt.consumer.JwtContext;
import java.security.Key;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import static org.eclipse.californium.core.coap.MediaTypeRegistry.*;
import static com.aaa_ngac_demo.AAA_NGAC_Consumer.Definitions.*;
/**
 * Hello world!
 *
 */
public class Consumer 
{

	private static final Logger LOG = Logger.getLogger(Consumer.class.getName());

	//The consumer will first send an authorisation request to the AAA system and if it gets a valid token then sends a consume request to the producer and prints 
	//the output from producer
    public static void main( String[] args )
    {
    	URI uri = null;
    	if (args.length > 0) {
			
			// input URI from command line arguments
			try {
				uri = new URI(args[0]);
			} catch (URISyntaxException e) {
				System.err.println("Invalid URI: " + e.getMessage());
				System.exit(-1);
			}
			CoapClient AuthorisationClient = new CoapClient(uri);
			DTLSConnector clientConnector = DtlsWrap_client(TRUST_STORE_LOCATION_CONSUMER, TRUST_STORE_PASSWORD_CONSUMER, KEY_STORE_LOCATION_CONSUMER, KEY_STORE_PASSWORD_CONSUMER, TRUST_STORE_ALIAS_ROOT, KEY_STORE_ALIAS_CONSUMER, 35399);
			if(clientConnector!= null)
			AuthorisationClient.setEndpoint(new CoapEndpoint(clientConnector, NetworkConfig.getStandard()));
			else
			{
				LOG.info("unable to set endpoint for DTLS, aborting consumer application");
				return;
			}
		  	AuthorisationClient.setTimeout(10000);
			Map<String, String> jsonargs = new HashMap<String, String>();
			jsonargs.put("Consumer", "Blinder_sys");
			jsonargs.put("ServiceName", "get_temp");
			jsonargs.put("Producer", "Temperature_sensor1");
			String json = createJSON("AuthRequest", jsonargs);
			//LOG.info(json);
			CoapResponse response =  AuthorisationClient.post(json,APPLICATION_JSON);
	      	AuthorisationClient.getEndpoint().stop();
			if(response.getOptions().getContentFormat()== APPLICATION_JSON)
			{
	    	 //   LOG.info("Received from server: " + response.getResponseText());
	    	    String accessResponse = retrieveAccessResponse(response.getResponseText());  	    
	    	    if(accessResponse == "false")
    	    {
    	      	LOG.info("Access not granted by authorisation system");
    	    }
    	    else
    	    {
    	    	String token = retrieveToken(response.getResponseText());
    	    	try {
    	    			uri = new URI(args[1]);
    				} 
    	    	catch (URISyntaxException e) 
    	    		{
    					System.err.println("Invalid URI: " + e.getMessage());
    					System.exit(-1);
    	    		}
        	    CoapClient ProducerClient = new CoapClient(uri);
    			clientConnector = DtlsWrap_client(TRUST_STORE_LOCATION_CONSUMER, TRUST_STORE_PASSWORD_CONSUMER, KEY_STORE_LOCATION_CONSUMER, KEY_STORE_PASSWORD_CONSUMER, TRUST_STORE_ALIAS_ROOT, KEY_STORE_ALIAS_CONSUMER, 35399);
    			if(clientConnector!= null)
    				ProducerClient.setEndpoint(new CoapEndpoint(clientConnector, NetworkConfig.getStandard()));
    			else
    			{
    				LOG.info("unable to set endpoint for DTLS, aborting consumer application");
    				return;
    			}
    			ProducerClient.setTimeout(10000);
        	    jsonargs = new HashMap<String, String>();
    			jsonargs.put("Consumer", "Blinder_sys");
    			jsonargs.put("ServiceName", "get_temp");
    			jsonargs.put("Producer", "Temperature_sensor1");
    			jsonargs.put("Token", token);
    			json = createJSON("ConsumeRequest", jsonargs);
    		//	LOG.info(json);
    			response =  ProducerClient.post(json,APPLICATION_JSON);
        	    LOG.info("Received from producer: " + response.getResponseText());
        	    ProducerClient.getEndpoint().stop();
        	    //second request without token but within the token validity period
        	    ProducerClient = new CoapClient(uri);
    			clientConnector =  DtlsWrap_client(TRUST_STORE_LOCATION_CONSUMER, TRUST_STORE_PASSWORD_CONSUMER, KEY_STORE_LOCATION_CONSUMER, KEY_STORE_PASSWORD_CONSUMER, TRUST_STORE_ALIAS_ROOT, KEY_STORE_ALIAS_CONSUMER, 35399);
        	    
    			if(clientConnector!= null)
    				ProducerClient.setEndpoint(new CoapEndpoint(clientConnector, NetworkConfig.getStandard()));
    			else
    			{
    				LOG.info("unable to set endpoint for DTLS, aborting consumer application");
    				return;
    			}

        	    jsonargs = new HashMap<String, String>();
    			jsonargs.put("Consumer", "Blinder_sys");
    			jsonargs.put("ServiceName", "get_temp");
    			jsonargs.put("Producer", "Temperature_sensor1");
    		//	jsonargs.put("Token", token);
    			json = createJSON("ConsumeRequest", jsonargs);
    		//	LOG.info(json);
    			response =  ProducerClient.post(json,APPLICATION_JSON);
    			 System.out.println("Received from producer:" + response.getResponseText());
     //   	    ProducerClient.getEndpoint().stop();
        	    
        	    try {  
        	    TimeUnit.SECONDS.sleep(65); // wait till token expires
        	    }
        	    catch(Exception e)
        	    {
        	    	e.printStackTrace();
        	    }
        	   for(int i=0;i<3;i++)
        	    {
        	    // second request without token but within the token validity period
    //    	    ProducerClient = new CoapClient(uri);
    //    	    ProducerClient = DtlsWrap_client(ProducerClient, TRUST_STORE_LOCATION_CONSUMER, TRUST_STORE_PASSWORD_CONSUMER, KEY_STORE_LOCATION_CONSUMER, KEY_STORE_PASSWORD_CONSUMER, TRUST_STORE_ALIAS_ROOT, KEY_STORE_ALIAS_CONSUMER, 35399);
        	    jsonargs = new HashMap<String, String>();
    			jsonargs.put("Consumer", "Blinder_sys");
    			jsonargs.put("ServiceName", "get_temp");
    			jsonargs.put("Producer", "Temperature_sensor1");
    		//	jsonargs.put("Token", token);
    			json = createJSON("ConsumeRequest", jsonargs);
    		//	LOG.info(json);
    			response =  ProducerClient.post(json,APPLICATION_JSON);
        	    LOG.info("Received from producer: " + response.getResponseText());
     //   	    ProducerClient.getEndpoint().stop();
        	    }
        
        	    //close request
      //  	    ProducerClient = new CoapClient(uri);
      //  	    ProducerClient = DtlsWrap_client(ProducerClient, TRUST_STORE_LOCATION_CONSUMER, TRUST_STORE_PASSWORD_CONSUMER, KEY_STORE_LOCATION_CONSUMER, KEY_STORE_PASSWORD_CONSUMER, TRUST_STORE_ALIAS_ROOT, KEY_STORE_ALIAS_CONSUMER, 35399);
        	    jsonargs = new HashMap<String, String>();
    			jsonargs.put("Consumer", "Blinder_sys");
    			jsonargs.put("ServiceName", "get_temp");
    			jsonargs.put("Producer", "Temperature_sensor1");
    		//	jsonargs.put("Token", token);
    			json = createJSON("CloseSession", jsonargs);
    		//	LOG.info(json);
    			response =  ProducerClient.post(json,APPLICATION_JSON);
        	    LOG.info("Received from producer: " + response.getResponseText());
       // 	    ProducerClient.getEndpoint().stop();
        	    
    	    }   
    	 }
			else
			{
	    	    LOG.info("Received from server: " + response.getResponseText());
			}
    	}
    	else
    	{
    		LOG.info("invalid args, needed : AAA server uri and producer uri ");
    	}
    	
    	BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        try {
        String s = br.readLine();
        }
        catch(Exception e)
        {
        	System.out.println(e);
        }    
    }
    
    //serverResponse is a Json object and retrieve token will parse it and retrieves the string corresponding to the key Token
    public static String retrieveToken(String serverResponse)
    {
		  JSONParser parser = new JSONParser();
		  String token = null;
		  try{
			  JSONObject jsonObject = (JSONObject) parser.parse(serverResponse);
		  
			  JSONObject jo = (JSONObject) jsonObject.get("AuthResponse");
			  Set<String> s = (Set<String>)jo.keySet();
			  token = (String)jo.get("Token");
		  }
		  catch(Exception e)
		  {
			  System.out.println(e);
		  }
		  return token;
			  
    }
    
    //serverResponse is a Json object and retrieveAccessResponse will parse it and retrieves the string corresponding to the key AccessResponse
    public static String retrieveAccessResponse(String serverResponse)
    {
		  JSONParser parser = new JSONParser();
		  String accessResponse = null;
		  try{
			  JSONObject jsonObject = (JSONObject) parser.parse(serverResponse);
		  
			  JSONObject jo = (JSONObject) jsonObject.get("AuthResponse");
			  Set<String> s = (Set<String>)jo.keySet();
			  accessResponse = (String)jo.get("AccessResponse");
		  }
		  catch(Exception e)
		  {
			  System.out.println(e);
		  }
		  return accessResponse;
			  
    }
    
	 public static String createJSON(String requestType, Map<String, String> jsonargs)
    {
        JSONObject obj = new JSONObject();
        for(String key: jsonargs.keySet())
		{
            obj.put(key, jsonargs.get(key));
		}
      
        JSONObject json = new JSONObject();
        json.put(requestType, obj);
      return json.toString();
    }

    public static DTLSConnector DtlsWrap_client(String client_trust_store, String client_trust_store_password,  String client_key_store,  String  client_key_password, String trust_store_alias, String client_alias, int port)
    {
    	DTLSConnector clientConnector = null;
  	  try {
	        KeyStore trustStore = KeyStore.getInstance("JKS");
	        InputStream inTrust = new FileInputStream(client_trust_store);
	        trustStore.load(inTrust, client_trust_store_password.toCharArray());
	        //load certificates
	        Certificate[] trustedCertificates = new Certificate[1];
	    //    trustedCertificates[0] = trustStore.getCertificate(trust_store_alias);
	        trustedCertificates[0] = trustStore.getCertificate(trust_store_alias);
	        LOG.fine(trustedCertificates[0].toString());
            KeyStore keyStore = KeyStore.getInstance("JKS");
            InputStream in = new FileInputStream(client_key_store);
            keyStore.load(in, client_key_password.toCharArray());
	        DtlsConnectorConfig.Builder clientConfig = new DtlsConnectorConfig.Builder();
	        clientConfig.setAddress(new InetSocketAddress(port));
	        clientConfig.setIdentity((PrivateKey)keyStore.getKey(client_alias, client_key_password.toCharArray()),
	        		keyStore.getCertificateChain(client_alias), false);
	        clientConfig.setMaxConnections(10);
	        clientConfig.setTrustStore(trustedCertificates);
	 //       clientConfig.setSupportedCipherSuites(new CipherSuite[]{
	   //                    CipherSuite.TLS_ECDHE_ECDSA_WITH_AES_128_CCM_8});
	        clientConnector = new DTLSConnector(clientConfig.build(), null);
	        clientConnector.clearConnectionState();

	        
	        		}
			catch(Exception e)
			{
				e.printStackTrace();
			}
      return clientConnector;

    }
}
