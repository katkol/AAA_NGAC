package com.aaa_ngac_demo.AAA_NGAC_Consumer;

public class Definitions {

    public static final String systemName = "Consumer"; 
    public final static String KEY_STORE_PASSWORD_CONSUMER = "password";
    public static final String KEY_STORE_LOCATION_CONSUMER = "resources/consumer_keystore.jks";   
    public final static String TRUST_STORE_PASSWORD_CONSUMER = "password";
    public static final String TRUST_STORE_LOCATION_CONSUMER = "resources/consumer_truststore.jks";  
    public static final String KEY_STORE_ALIAS_CONSUMER = "consumer";
    public static final String TRUST_STORE_ALIAS_ROOT = "consumer";
    public static final String TRUST_STORE_ALIAS_AAA = "server-cert";
    public static final String TRUST_STORE_ALIAS_PRODUCER = "producer";
}
